print("====Selamat datang di toko Andi Tersenyum, Selamat belanja!====")
total= int(input("total harga belanja:Rp"))
diskon1= int(total-(total*0.02))
diskon2= int(total-(total*0.05))
diskon3= int(total-(total*0.10))
if total < 100000:
         print("Tidak ada diskon! Maka yang anda bayarkan adalah",total)
elif total <= 100000:
         print("Biaya yang harus kalian bayar setelah diskon adalah",diskon1)
elif total >= 500000:
         print("Biaya yang harus kalian bayar setelah diskon adalah",diskon2)
elif total >= 999999:
         print("Biaya yang harus kalian bayar setelah diskon adalah",diskon3)
      